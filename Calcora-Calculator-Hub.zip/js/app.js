const calculators=[
{id:"percentage",name:"Percentage Calculator",cat:"Math",icon:"%",desc:"Find percentages, percentage change and more.",url:"calculators/percentage.html"},
{id:"loan",name:"Loan Calculator",cat:"Finance",icon:"$",desc:"Estimate monthly payments and total loan cost.",url:"calculators/loan.html"},
{id:"bmi",name:"BMI Calculator",cat:"Health",icon:"⚕",desc:"Calculate body mass index from height and weight.",url:"calculators/bmi.html"},
{id:"age",name:"Age Calculator",cat:"Date & Time",icon:"◷",desc:"Calculate exact age from a date of birth.",url:"calculators/age.html"},
{id:"compound",name:"Compound Interest",cat:"Finance",icon:"↗",desc:"Estimate growth using compound interest.",url:"calculators/compound.html"},
{id:"unit",name:"Unit Converter",cat:"Conversion",icon:"⇄",desc:"Convert common length, weight and temperature units.",url:"calculators/unit.html"},
{id:"area",name:"Area Calculator",cat:"Geometry",icon:"△",desc:"Calculate areas of common geometric shapes.",url:"calculators/area.html"},
{id:"calorie",name:"Calorie Calculator",cat:"Health",icon:"◉",desc:"Estimate daily calorie needs using BMR and activity.",url:"calculators/calorie.html"},
{id:"average",name:"Average Calculator",cat:"Math",icon:"x̄",desc:"Calculate the mean of a set of numbers.",url:"calculators/average.html"}
];
const cats=[["Math","∑","Numbers, percentages and formulas."],["Finance","$","Loans, interest and investments."],["Health","⚕","General health and fitness estimates."],["Date & Time","◷","Age, dates and durations."],["Conversion","⇄","Units, measurements and values."],["Geometry","△","Areas, volumes and shapes."],["Science","⚛","Scientific and educational tools."],["Business","▣","Useful tools for work and business."],["Statistics","▥","Descriptive statistics and data."],["Everyday","✓","Practical everyday calculations."]];
const cg=document.querySelector("#categoriesGrid"), grid=document.querySelector("#calculatorGrid"), empty=document.querySelector("#empty"), search=document.querySelector("#search");
cg.innerHTML=cats.map(c=>`<div class="category" data-cat="${c[0]}"><div class="emoji">${c[1]}</div><h3>${c[0]}</h3><p>${c[2]}</p></div>`).join("");
function render(list){grid.innerHTML=list.map(x=>`<a class="calc-card" href="${x.url}"><span class="tag">${x.icon} &nbsp;${x.cat}</span><h3>${x.name}</h3><p>${x.desc}</p><span class="open">Open calculator →</span></a>`).join("");empty.classList.toggle("hidden",!list.length)}
render(calculators);
search.addEventListener("input",e=>{const q=e.target.value.toLowerCase();render(calculators.filter(x=>(x.name+" "+x.cat+" "+x.desc).toLowerCase().includes(q)))});
cg.addEventListener("click",e=>{const card=e.target.closest(".category");if(!card)return;search.value=card.dataset.cat;render(calculators.filter(x=>x.cat===card.dataset.cat));document.querySelector("#popular").scrollIntoView({behavior:"smooth"})});
document.querySelector("#themeBtn").onclick=()=>document.body.classList.toggle("dark");
if("serviceWorker" in navigator) navigator.serviceWorker.register("sw.js");
