# Calcora Calculator Hub

A modern, responsive, SEO-oriented calculator platform starter built with HTML, CSS and vanilla JavaScript.

## Included
- Responsive homepage
- Calculator search and category filtering
- 9 working calculators
- Dark mode
- PWA service worker
- SEO metadata, robots.txt and sitemap.xml
- Modular calculator CSS/JS
- Browser-side calculations

## Run locally
Open `index.html` directly, or serve the directory with any static HTTP server.

Example:
`python -m http.server 8000`

Then visit `http://localhost:8000`.

## Add a calculator
1. Create a new page under `calculators/`.
2. Add the calculator logic.
3. Add its metadata to `js/app.js`.
4. Add its URL to `sitemap.xml`.
5. Test mobile, keyboard navigation, invalid inputs and formula edge cases.

## Production roadmap
- Add a build system and automated tests.
- Add JSON-LD per calculator.
- Generate category pages and dynamic sitemap.
- Add localization/RTL.
- Add privacy-friendly analytics.
- Add comprehensive unit tests for all formulas.
